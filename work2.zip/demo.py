result = 3+5
print(result)
